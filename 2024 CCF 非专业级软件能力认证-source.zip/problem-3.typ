#import "header.typ": *

#heading(depth: 2, [#"题目描述"])
#par[#"小 S 想要举办一场擂台游戏，如果共有 "#mi(block: false, "2^k")#" 名选手参加，那么游戏分为 "#mi(block: false, "k")#" 轮进行："]
#list(
[#"第一轮编号为 "#mi(block: false, "1, 2")#" 的选手进行一次对局，编号为 "#mi(block: false, "3, 4")#" 的选手进行一次对局，以此类推，编号为 "#mi(block: false, "2^k - 1, 2^k")#" 的选手进行一次对局。"],
[#"第二轮在只保留第一轮的胜者的前提下，相邻的两位依次进行一场对局。"],
[#"以此类推，第 "#mi(block: false, "k - 1")#" 轮在只保留第 "#mi(block: false, "k - 2")#" 轮的 "#mi(block: false, "4")#" 位胜者的前提下，前两位、后两位分别进行对局，也就是所谓的半决赛。"],
[#"第 "#mi(block: false, "k")#" 轮即为半决赛两位胜者的决赛。"],
)
#par[#"确定了游戏晋级的规则后，小 S 将比赛的规则设置为了擂台赛。具体而言，每位选手都有一个能力值 "#mi(block: false, "a_1, a_2, \\dots , a_{2^k}")#"，能力值为 "#mi(block: false, "[0,2^{31}-1]")#" 之内的整数。对于每场比赛，会先抽签决定一个数 "#mi(block: false, "0/1")#"，我们将第 "#mi(block: false, "R")#" 轮的第 "#mi(block: false, "G")#" 场比赛抽到的数记为 "#mi(block: false, "d_{R,G}")#"。抽到 "#mi(block: false, "0")#" 则表示表示编号小的选手为擂主，抽到 "#mi(block: false, "1")#" 则表示编号大的选手为擂主。擂主获胜当且仅当他的能力值 "#mi(block: false, "a\\geq R")#"。也就是说，游戏的胜负只取决于"#strong[#"擂主的能力值"]#"与"#strong[#"当前比赛是第几轮"]#"的大小关系，"#strong[#"与另一位的能力值无关"]#"。"]
#par[#"现在，小 S 先后陆续收到了 "#mi(block: false, "n")#" 位选手的报名信息，他们分别告知了小 S 自己的能力值。小 S 会按照报名的先后顺序对选手进行编号为 "#mi(block: false, "1, 2, \\dots, n")#"。小 S 关心的是，补充"#strong[#"尽量少"]#"的选手使总人数为 "#mi(block: false, "2")#" 的整次幂，且所有选手进行一次完整的擂台游戏后，所有可能成为总冠军的选手的"#strong[#"编号之和"]#"是多少。"]
#par[#"形式化地，设 "#mi(block: false, "k")#" 是最小的非负整数使得 "#mi(block: false, "2^k\\geq n")#"，那么应当补充 "#mi(block: false, "(2^k-n)")#" 名选手，且补充的选手的能力值可以任取 "#mi(block: false, "[0,2^{31}-1]")#" 之内的整数。"#strong[#"如果补充的选手有可能取胜，也应当计入答案中"]#"。"]
#par[#"当然小 S 觉得这个问题还是太简单了，所以他给了你 "#mi(block: false, "m")#" 个询问 "#mi(block: false, "c_1,c_2,\\dots,c_m")#"。小 S 希望你帮忙对于每个 "#mi(block: false, "c_i")#" 求出，在只收到前 "#mi(block: false, "c_i")#" 位选手的报名信息时，这个问题的答案是多少。"]
#heading(depth: 2, [#"输入格式"])
#par[#"从文件 "#emph[#"arena.in"]#" 中读入数据。"]
#par[#strong[#"本题的测试点包含有多组测试数据。"]#" 但不同测试数据只是通过修改 "#mi(block: false, "a_1, a_2, \\dots , a_n")#" 得到，其他内容均保持不变，请参考以下格式。其中 "#mi(block: false, "\\oplus")#" 代表异或运算符，"#mi(block: false, "a \\bmod b")#" 代表 "#mi(block: false, "a")#" 除以 "#mi(block: false, "b")#" 的余数。"]
#par[#"输入的第一行包含两个正整数 "#mi(block: false, "n, m")#"，表示报名的选手数量和询问的数量。"]
#par[#"输入的第二行包含 "#mi(block: false, "n")#" 个非负整数 "#mi(block: false, "a'_1,a'_2,\\dots,a'_n")#"，这列数将用来计算真正的能力值。"]
#par[#"输入的第三行包含 "#mi(block: false, "m")#" 个正整数 "#mi(block: false, "c_1, c_2, \\dots , c_m")#"，表示询问。"]
#par[#"设 "#mi(block: false, "K")#" 是使得 "#mi(block: false, "2^K \\geq n")#" 的最小的非负整数，接下来的 "#mi(block: false, "K")#" 行当中，第 "#mi(block: false, "R")#" 行包含 "#mi(block: false, "2^{K-R}")#" 个数（无空格），其中第 "#mi(block: false, "G")#" 个数表示第 "#mi(block: false, "R")#" 轮的第 "#mi(block: false, "G")#" 场比赛抽签得到的 "#mi(block: false, "d_{R,G}=0/1")#"。"]
#par[#"注意，由于询问只是将人数凑齐到 "#mi(block: false, "2^k\\geq c_i")#"，这里的 "#mi(block: false, "k\\leq K")#"，因此你未必会用到全部的输入值。"]
#par[#"接下来一行包含一个正整数 "#mi(block: false, "T")#"，表示有 "#mi(block: false, "T")#" 组测试数据。"]
#par[#"接下来共 "#mi(block: false, "T")#" 行，每行描述一组数据，包含 "#mi(block: false, "4")#" 个非负整数 "#mi(block: false, "X_0,X_1,X_2,X_3")#"，该组数据的能力值 "#mi(block: false, "a_i=a'_i \\oplus X_{i\\bmod 4}")#"，其中 "#mi(block: false, "1\\leq i\\leq n")#"。"]
#heading(depth: 2, [#"输出格式"])
#par[#"输出到文件 "#emph[#"arena.out"]#" 中。"]
#par[#"共输出 "#mi(block: false, "T")#" 行，对于每组数据，设 "#mi(block: false, "A_i")#" 为第 "#mi(block: false, "i")#"（"#mi(block: false, "1 \\leq i \\leq m")#"）组询问的答案，你只需要输出一行包含一个整数，表示 "#mi(block: false, "(1\\times A_1) \\oplus (2\\times A_2) \\oplus \\dots \\oplus (m\\times A_m)")#" 的结果。"]
#heading(depth: 2, [#"样例 1 输入"])
#raw(block: true, lang: "txt", "5 5\n0 0 0 0 0\n5 4 1 2 3\n1001\n10\n1\n4\n2 1 0 0\n1 2 1 0\n0 2 3 1\n2 2 0 1")
#heading(depth: 2, [#"样例 1 输出"])
#raw(block: true, lang: "txt", "5\n19\n7\n1")
#heading(depth: 2, [#"样例 1 解释"])
#par[#"共有 "#mi(block: false, "T = 4")#" 组数据，这里只解释第一组。"#mi(block: false, "5")#" 名选手的真实能力值为 "#mi(block: false, "[1, 0, 0, 2, 1]")#"。"#mi(block: false, "5")#" 组询问分别是对长度为 "#mi(block: false, "5, 4, 1, 2, 3")#" 的前缀进行的。"]
#enum(start: 1,
[#"对于长度为 "#mi(block: false, "1")#" 的前缀，由于只有 "#mi(block: false, "1")#" 号一个人，因此答案为 "#mi(block: false, "1")#"。"],
[#"对于长度为 "#mi(block: false, "2")#" 的前缀，由于 "#mi(block: false, "2")#" 个人已经是 "#mi(block: false, "2")#" 的幂次，因此不需要进行扩充。根据抽签 "#mi(block: false, "d_{1,1} = 1")#" 可知 "#mi(block: false, "2")#" 号为擂主，由于 "#mi(block: false, "a_2 < 1")#"，因此 "#mi(block: false, "1")#" 号获胜，答案为 "#mi(block: false, "1")#"。"],
[#"对于长度为 "#mi(block: false, "3")#" 的前缀，首先 "#mi(block: false, "1")#" 号、"#mi(block: false, "2")#" 号比赛是 "#mi(block: false, "1")#" 号获胜（因为 "#mi(block: false, "d_{1,1} = 1")#"，故 "#mi(block: false, "2")#" 号为擂主，"#mi(block: false, "a_2 < 1")#"），然后虽然 "#mi(block: false, "4")#" 号能力值还不知道，但 "#mi(block: false, "3")#" 号、"#mi(block: false, "4")#" 号比赛一定是 "#mi(block: false, "4")#" 号获胜（因为 "#mi(block: false, "d_{1,2} = 0")#"，故 "#mi(block: false, "3")#" 号为擂主，"#mi(block: false, "a_3 < 1")#"），而决赛 "#mi(block: false, "1")#" 号、"#mi(block: false, "4")#" 号谁获胜都有可能（因为 "#mi(block: false, "d_{2,1} = 1")#"，故 "#mi(block: false, "4")#" 号为擂主，如果 "#mi(block: false, "a_4 < 2")#" 则 "#mi(block: false, "1")#" 号获胜，"#mi(block: false, "a_4 \\geq 2")#" 则 "#mi(block: false, "4")#" 号获胜）。综上所述，答案为 "#mi(block: false, "1 + 4 = 5")#"。"],
[#"对于长度为 "#mi(block: false, "4")#" 的前缀，我们根据上一条的分析得知，由于 "#mi(block: false, "a_4 \\geq 2")#" ，所以决赛获胜的是 "#mi(block: false, "4")#" 号。"],
[#"对于长度为 "#mi(block: false, "5")#" 的前缀，可以证明，可能获胜的选手包括 "#mi(block: false, "4")#" 号、"#mi(block: false, "7")#" 号、"#mi(block: false, "8")#" 号，答案为 "#mi(block: false, "19")#"。"],
)
#par[#"因此，该组测试数据的答案为 "#mi(block: false, "(1 \\times 19) \\oplus (2 \\times 4) \\oplus (3 \\times 1) \\oplus (4 \\times 1) \\oplus (5 \\times 5) = 5")#"。"]
#heading(depth: 2, [#"样例 2"])
#par[#"见选手目录下的 "#emph[#"arena/arena2.in"]#" 与 "#emph[#"arena/arena2.ans"]#"。"]
#par[#"这组样例满足特殊性质 A。"]
#heading(depth: 2, [#"样例 3"])
#par[#"见选手目录下的 "#emph[#"arena/arena3.in"]#" 与 "#emph[#"arena/arena3.ans"]#"。"]
#par[#"这组样例满足特殊性质 B。"]
#heading(depth: 2, [#"样例 4"])
#par[#"见选手目录下的 "#emph[#"arena/arena4.in"]#" 与 "#emph[#"arena/arena4.ans"]#"。"]
#heading(depth: 2, [#"样例 5"])
#par[#"见选手目录下的 "#emph[#"arena/arena5.in"]#" 与 "#emph[#"arena/arena5.ans"]#"。"]
#heading(depth: 2, [#"数据范围"])
#par[#"对于所有测试数据，保证："#mi(block: false, "2 \\leq n, m \\leq 10^5")#"，"#mi(block: false, "0 \\leq a_i, X_j < 2^{31}")#"，"#mi(block: false, "1 \\leq c_i \\leq n")#"，"#mi(block: false, "1 \\leq T \\leq 256")#"。"]
#figure(table(columns: 5, align: (center + horizon, center + horizon, center + horizon, center + horizon, center + horizon, ),
table.cell()[#"测试点"], table.cell()[#mi(block: false, "T=")], table.cell()[#mi(block: false, "n,m\\leq")], table.cell()[#"特殊性质 A"], table.cell()[#"特殊性质 B"], 
table.cell()[#mi(block: false, "1\\sim 3")], table.cell(rowspan: 6, )[#mi(block: false, "1")], table.cell()[#mi(block: false, "8")], table.cell()[#"否"], table.cell(rowspan: 2, )[#"否"], 
table.cell()[#mi(block: false, "4,5")], table.cell(rowspan: 2, )[#mi(block: false, "500")], table.cell()[#"是"], 
table.cell()[#mi(block: false, "6\\sim 8")], table.cell(rowspan: 2, )[#"否"], table.cell()[#"是"], 
table.cell()[#mi(block: false, "9,10")], table.cell()[#mi(block: false, "5000")], table.cell(rowspan: 2, )[#"否"], 
table.cell()[#mi(block: false, "11,12")], table.cell(rowspan: 7, )[#mi(block: false, "10^5")], table.cell()[#"是"], 
table.cell()[#mi(block: false, "13\\sim 15")], table.cell(rowspan: 6, )[#"否"], table.cell()[#"是"], 
table.cell()[#mi(block: false, "16,17")], table.cell()[#mi(block: false, "4")], table.cell(rowspan: 5, )[#"否"], 
table.cell()[#mi(block: false, "18,19")], table.cell()[#mi(block: false, "16")], 
table.cell()[#mi(block: false, "20,21")], table.cell()[#mi(block: false, "64")], 
table.cell()[#mi(block: false, "22,23")], table.cell()[#mi(block: false, "128")], 
table.cell()[#mi(block: false, "24,25")], table.cell()[#mi(block: false, "256")], 
))
#par[#"特殊性质 A：保证询问的 "#mi(block: false, "c_i")#" 均为 "#mi(block: false, "2")#" 的幂次。"]
#par[#"特殊性质 B：保证所有的 "#mi(block: false, "d_{R,G} = 0")#"。"]

#hide(place(top+left, [
]))
