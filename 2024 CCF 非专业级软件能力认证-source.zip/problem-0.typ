#import "header.typ": *

#heading(depth: 2, [#"题目描述"])
#par[#"今天是小 Q 的生日，他得到了 "#mi(block: false, "n")#" 张卡牌作为礼物。这些卡牌属于火爆的“决斗怪兽”，其中，第 "#mi(block: false, "i")#" 张卡代表一只攻击力为 "#mi(block: false, "r_i")#"，防御力也为 "#mi(block: false, "r_i")#" 的怪兽。"]
#par[#"一场游戏分为若干回合。每回合，小 Q 会选择某只怪兽 "#mi(block: false, "i")#" 以及"#strong[#"另一只"]#"怪兽 "#mi(block: false, "j(i \\neq j)")#"，并让怪兽 "#mi(block: false, "i")#" 向怪兽 "#mi(block: false, "j")#" 发起攻击。此时，若怪兽 "#mi(block: false, "i")#" 的攻击力小于等于怪兽 "#mi(block: false, "j")#" 的防御力，则无事发生；否则，怪兽 "#mi(block: false, "j")#" 的防御被打破，怪兽 "#mi(block: false, "j")#" 退出游戏不再参与到剩下的游戏中。一只怪兽在整场游戏中"#strong[#"至多"]#"只能发起一次攻击。当未退出游戏的怪兽都已发起过攻击时，游戏结束。"]
#par[#"小 Q 希望决定一组攻击顺序，使得在游戏结束时，未退出游戏的怪兽数量尽可能少。"]
#heading(depth: 2, [#"输入格式"])
#par[#"从文件 "#emph[#"duel.in"]#" 中读入数据。"]
#par[#"输入的第一行包含一个正整数 "#mi(block: false, "n")#"，表示卡牌的个数。"]
#par[#"输入的第二行包含 "#mi(block: false, "n")#" 个正整数，其中第 "#mi(block: false, "i")#" 个正整数表示第 "#mi(block: false, "i")#" 个怪兽的攻击力及防御力 "#mi(block: false, "r_i")#"。"]
#heading(depth: 2, [#"输出格式"])
#par[#"输出到文件 "#emph[#"duel.out"]#" 中。"]
#par[#"输出一行包含一个整数表示游戏结束时未退出游戏的怪兽数量的最小值。"]
#heading(depth: 2, [#"样例 1 输入"])
#raw(block: true, lang: "txt", "5\n1 2 3 1 2")
#heading(depth: 2, [#"样例 1 输出"])
#raw(block: true, lang: "txt", "2")
#heading(depth: 2, [#"样例 1 解释"])
#par[#"其中一种最优方案为：第一回合让第 "#mi(block: false, "2")#" 只怪兽向第 "#mi(block: false, "1")#" 只怪兽发起攻击，第二回合让第 "#mi(block: false, "5")#" 只怪兽向第 "#mi(block: false, "4")#" 只怪兽发起攻击，第三回合让第 "#mi(block: false, "3")#" 只怪兽向第 "#mi(block: false, "5")#" 只怪兽发起攻击。此时没有退出游戏的怪兽都进行过攻击，游戏结束。可以证明没有更优的攻击顺序。"]
#heading(depth: 2, [#"样例 2 输入"])
#raw(block: true, lang: "txt", "10\n136 136 136 2417 136 136 2417 136 136 136")
#heading(depth: 2, [#"样例 2 输出"])
#raw(block: true, lang: "txt", "8")
#heading(depth: 2, [#"样例 3"])
#par[#"见选手目录下的 "#emph[#"duel/duel3.in"]#" 与 "#emph[#"duel/duel3.ans"]#"。"]
#par[#"该样例满足 "#mi(block: false, "\\forall 1 \\leq i \\leq n, r_i \\leq 2")#"。"]
#heading(depth: 2, [#"样例 4"])
#par[#"见选手目录下的 "#emph[#"duel/duel4.in"]#" 与 "#emph[#"duel/duel4.ans"]#"。"]
#heading(depth: 2, [#"数据范围"])
#par[#"对于所有测试数据，保证："#mi(block: false, "1 \\leq n \\leq 10^5")#"，"#mi(block: false, "1 \\leq r_i \\leq 10^5")#"。"]
#figure(table(columns: 4, align: (center + horizon, center + horizon, center + horizon, center + horizon, ),
table.cell()[#"测试点"], table.cell()[#mi(block: false, "n")], table.cell()[#mi(block: false, "r_i")], table.cell()[#"特殊性质"], 
table.cell()[#mi(block: false, "1\\sim 4")], table.cell()[#mi(block: false, "\\leq 10")], table.cell()[#mi(block: false, "\\leq 10^5")], table.cell(rowspan: 2, )[#"无特殊性质"], 
table.cell()[#mi(block: false, "5\\sim 10")], table.cell()[#mi(block: false, "\\leq 10^5")], table.cell()[#mi(block: false, "\\leq 2")], 
table.cell()[#mi(block: false, "11\\sim 15")], table.cell()[#mi(block: false, "\\leq 30")], table.cell(rowspan: 2, )[#mi(block: false, "\\leq 10^5")], table.cell()[#"特殊性质 A"], 
table.cell()[#mi(block: false, "16\\sim 20")], table.cell()[#mi(block: false, "\\leq 10^5")], table.cell()[#"无特殊性质"], 
))
#par[#"特殊性质 A：保证每个 "#mi(block: false, "r_i")#" 在可能的值域中独立均匀随机生成。\n`"]

#hide(place(top+left, [
]))
