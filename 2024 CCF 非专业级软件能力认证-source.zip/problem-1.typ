#import "header.typ": *

#heading(depth: 2, [#"题目描述"])
#par[#"小 D 新入职了某国的交管部门，他的第一个任务是负责国家的一条长度为 "#mi(block: false, "L")#" 的南北主干道的车辆超速检测。为了考考小 D，上司首先需要他解决一个简化的场景。"]
#par[#"这个周末，主干道上预计出现 "#mi(block: false, "n")#" 辆车，其中第 "#mi(block: false, "i")#" 辆车从主干道上距离最南端 "#mi(block: false, "d_i")#" 的位置驶入，以 "#mi(block: false, "v_i")#" 的初速度和 "#mi(block: false, "a_i")#" 的加速度做匀加速运动向北行驶。我们只考虑从南向北的车辆，故 "#mi(block: false, "v_i > 0")#"，但 "#mi(block: false, "a_i")#" 可正可负，也可以为零。当车辆行驶到主干道最北端（即距离最南端为 "#mi(block: false, "L")#" 的位置）或速度降为 "#mi(block: false, "0")#"（这只可能在 "#mi(block: false, "a_i < 0")#" 时发生）时，我们认为该车驶离主干道。"]
#par[#"主干道上设置了 "#mi(block: false, "m")#" 个测速仪，其中第 "#mi(block: false, "j")#" 个测速仪位于主干道上距离最南端 "#mi(block: false, "p_j")#" 的位置，每个测速仪可以设置开启或关闭。当某辆车经过某个开启的测速仪时，若这辆车的瞬时速度"#strong[#"超过"]#"了道路限速 "#mi(block: false, "V")#"，那么这辆车就会被判定为超速。注意当车辆驶入与驶出主干道时，如果在对应位置有一个开启的测速仪，这个测速仪也会对这辆车进行测速。"]
#par[#"上司首先想知道，如果所有测速仪都是开启的，那么这 "#mi(block: false, "n")#" 辆车中会有多少辆车被判定为超速。"]
#par[#"其次，为了节能，部门想关闭一部分测速仪。然而，他们不希望漏掉超速的车，也就是说，当 "#mi(block: false, "n")#" 辆车里的某辆车在所有测速仪都开启时被判定为超速，他们希望在关闭一部分测速仪以后它依然被判定为超速。上司还想知道在这样的条件下最多可以关闭多少测速仪。"]
#par[#"由于 "#mi(block: false, "n")#" 很大，上司允许小 D 使用编程解决这两个问题，于是小 D 找到了你。"]
#par[#"如果你对于加速度并不熟悉，小 D 贴心地在本题的“提示”部分提供了有关加速度的公式。"]
#heading(depth: 2, [#"输入格式"])
#par[#"从文件 "#emph[#"detect.in"]#" 中读入数据。"]
#par[#"输入的第一行包含一个正整数 "#mi(block: false, "T")#"，表示数据组数。"]
#par[#"接下来包含 "#mi(block: false, "T")#" 组数据，每组数据的格式如下："]
#par[#"第一行包含四个整数 "#mi(block: false, "n, m, L, V")#"，分别表示车辆数量、测速仪数量、主干道长度和道路限速。"]
#par[#"接下来 "#mi(block: false, "n")#" 行："]
#par[#"第 "#mi(block: false, "i")#" 行包含三个整数 "#mi(block: false, "d_i, v_i, a_i")#" 描述一辆车。"]
#par[#"最后一行包含 "#mi(block: false, "m")#" 个整数 "#mi(block: false, "p_1, p_2, \\dots , p_m")#" 描述道路上所有测速仪的位置。"]
#heading(depth: 2, [#"输出格式"])
#par[#"输出到文件 "#emph[#"detect.out"]#" 中。"]
#par[#"对于每组数据：输出一行包含两个整数，第一个整数为所有测速仪都开启时被判定为超速的车辆数量，第二个整数为在不漏掉超速车辆的前提下最多可以关闭的测速仪数量。"]
#heading(depth: 2, [#"样例 1 输入"])
#raw(block: true, lang: "txt", "1\n5 5 15 3\n0 3 0\n12 4 0\n1 1 4\n5 5 -2\n6 4 -4\n2 5 8 9 15")
#heading(depth: 2, [#"样例 1 输出"])
#raw(block: true, lang: "txt", "3 3")
#heading(depth: 2, [#"样例 1 解释"])
#par[#"在该组测试数据中，主干道长度为 "#mi(block: false, "15")#"，限速为 "#mi(block: false, "3")#"，在距离最南端 "#mi(block: false, "2, 5, 8, 9, 15")#" 的位置各设有一个测速仪。"]
#list(
[#"第一辆车在最南端驶入，以 "#mi(block: false, "3")#" 的速度匀速行驶。这辆车在整个路段上都没有超速。"],
[#"第二辆车在距离最南端 "#mi(block: false, "12")#" 的位置驶入，以 "#mi(block: false, "4")#" 的速度匀速行驶。在最北端驶离主干道时，它会被距离最南端 "#mi(block: false, "15")#" 的测速仪判定为超速。"],
[#"第三辆车在距离最南端 "#mi(block: false, "1")#" 的位置驶入，以 "#mi(block: false, "1")#" 的初速度、"#mi(block: false, "4")#" 的加速度行驶。其在行驶了 "#mi(block: false, "\\frac{3^2-1^2}{2\\times 4}=1")#" 的距离，即到达 "#mi(block: false, "2")#" 的位置时，速度变为 "#mi(block: false, "3")#"，并在之后一直超速。因此这辆车会被除了距离最南端 "#mi(block: false, "2")#" 的测速仪以外的其他测速仪判定为超速。"],
[#"第四辆车在距离最南端 "#mi(block: false, "5")#" 的位置驶入，以 "#mi(block: false, "5")#" 的初速度、"#mi(block: false, "-2")#" 的加速度行驶。其在行驶了 "#mi(block: false, "\\frac{3^2-5^2}{2\\times (-2)}")#" 的距离，即到达 "#mi(block: false, "9")#" 的位置时，速度变为 "#mi(block: false, "3")#"。因此这辆车在距离最南端 "#mi(block: false, "[5, 9)")#" 时超速，会被距离最南端 "#mi(block: false, "5")#" 和 "#mi(block: false, "8")#" 的两个测速仪判定为超速。"],
[#"第五辆车在距离最南端 "#mi(block: false, "6")#" 的位置驶入，以 "#mi(block: false, "4")#" 的初速度、"#mi(block: false, "−4")#" 的加速度行驶。在其行驶了 "#mi(block: false, "\\frac{3^2-4^2}{2\\times (-4)}=\\frac{7}{8}")#" 的距离后，即这辆车到达 "#mi(block: false, "6\\frac{7}{8}")#" 的位置时，其速度变为 "#mi(block: false, "3")#"。因此这辆车在距离最南端 "#mi(block: false, "[6,6\\frac{7}{8})")#" 时超速，但这段区间内没有测速仪，因此不会被判定为超速。"],
)
#par[#"因此第二、三、四辆车会被判定为超速，输出的第一个数为 "#mi(block: false, "3")#"。"]
#par[#"我们可以关闭距离最南端 "#mi(block: false, "2, 8, 9")#" 的三个测速仪，保留 "#mi(block: false, "5")#" 和 "#mi(block: false, "15")#" 的两个测速仪，此时三辆之前被判定为超速的车依然被判定为超速。可以证明不存在更优方案，因此输出的第二个数为 "#mi(block: false, "3")#"。"]
#heading(depth: 2, [#"样例 2"])
#par[#"见选手目录下的 "#emph[#"detect/detect2.in"]#" 与 "#emph[#"detect/detect2.ans"]#"。"]
#par[#"该组样例满足 "#mi(block: false, "n, m \\leq 10")#"。"]
#heading(depth: 2, [#"样例 3"])
#par[#"见选手目录下的 "#emph[#"detect/detect3.in"]#" 与 "#emph[#"detect/detect3.ans"]#"。"]
#par[#"该组样例满足特殊性质 A，其中前十组测试数据满足 "#mi(block: false, "n, m \\leq 3000")#"。"]
#heading(depth: 2, [#"样例 4"])
#par[#"见选手目录下的 "#emph[#"detect/detect4.in"]#" 与 "#emph[#"detect/detect4.ans"]#"。"]
#par[#"该组样例满足特殊性质 B，其中前十组测试数据满足 "#mi(block: false, "n, m \\leq 3000")#"。"]
#heading(depth: 2, [#"样例 5"])
#par[#"见选手目录下的 "#emph[#"detect/detect5.in"]#" 与 "#emph[#"detect/detect5.ans"]#"。"]
#par[#"该组样例满足特殊性质 C，其中前十组测试数据满足 "#mi(block: false, "n, m \\leq 3000")#"。"]
#heading(depth: 2, [#"数据范围"])
#par[#"对于所有测试数据，保证："]
#list(
[#mi(block: false, "1 \\leq T \\leq 20")#"；"],
[#mi(block: false, "1 \\leq n, m \\leq 10^5")#"，"#mi(block: false, "1 \\leq L \\leq 10^6")#"，"#mi(block: false, "1 \\leq V \\leq 10^3")#"；"],
[#mi(block: false, "0 \\leq d_i < L")#"，"#mi(block: false, "1 \\leq v_i \\leq 10^3")#"，"#mi(block: false, "|a_i| \\leq 10^3")#"；"],
[#mi(block: false, "0 \\leq p_1 < p_2 < \\dots < p_m \\leq L")#"。"],
)
#figure(table(columns: 3, align: (center + horizon, center + horizon, center + horizon, ),
table.cell()[#"测试点"], table.cell()[#mi(block: false, "n,m\\leq")], table.cell()[#"特殊性质"], 
table.cell()[#mi(block: false, "1")], table.cell()[#mi(block: false, "10")], table.cell(rowspan: 2, )[#"无"], 
table.cell()[#mi(block: false, "2")], table.cell()[#mi(block: false, "20")], 
table.cell()[#mi(block: false, "3")], table.cell()[#mi(block: false, "3000")], table.cell(rowspan: 2, )[#"A"], 
table.cell()[#mi(block: false, "4")], table.cell()[#mi(block: false, "10^5")], 
table.cell()[#mi(block: false, "5")], table.cell()[#mi(block: false, "3000")], table.cell(rowspan: 2, )[#"B"], 
table.cell()[#mi(block: false, "6")], table.cell()[#mi(block: false, "10^5")], 
table.cell()[#mi(block: false, "7")], table.cell()[#mi(block: false, "3000")], table.cell(rowspan: 2, )[#"C"], 
table.cell()[#mi(block: false, "8")], table.cell()[#mi(block: false, "10^5")], 
table.cell()[#mi(block: false, "9")], table.cell()[#mi(block: false, "3000")], table.cell(rowspan: 2, )[#"无"], 
table.cell()[#mi(block: false, "10")], table.cell()[#mi(block: false, "10^5")], 
))
#par[#"特殊性质 A：保证 "#mi(block: false, "a_i = 0")#"。"]
#par[#"特殊性质 B：保证 "#mi(block: false, "a_i > 0")#"。"]
#par[#"特殊性质 C：保证 "#mi(block: false, "a_i < 0")#"，且所有车都不在最北端驶离主干道。"]
#heading(depth: 2, [#"提示"])
#par[#"与加速度有关的定义和公式如下："]
#list(
[#"匀加速运动是指物体在运动过程中，加速度保持不变的运动，即每单位时间内速度的变化量是恒定的。"],
[#"当一辆车的初速度为 "#mi(block: false, "v_0")#"、加速度 "#mi(block: false, "a\\neq 0")#"，做匀加速运动，则 "#mi(block: false, "t")#" 时刻后它的速度 "#mi(block: false, "v_1 = v_0 + a \\times t")#"，它的位移（即行驶路程）"#mi(block: false, "s=v_0\\times t+0.5\\times a\\times t^2")#"。"],
[#"当一辆车的初速度为 "#mi(block: false, "v_0")#"、加速度 "#mi(block: false, "a \\neq 0")#"，做匀加速运动，则当它的位移（即行驶路程）为 "#mi(block: false, "s")#" 时，这辆车的瞬时速度为 "#mi(block: false, "\\sqrt{v_0^2+2\\times a\\times s}")#"。"],
[#"当一辆车的初速度为 "#mi(block: false, "v_0")#"、加速度 "#mi(block: false, "a \\neq 0")#"，在它的位移（即行驶路程）为 "#mi(block: false, "\\frac{v_1^2-v_0^2}{2a}")#" 时，这辆车的瞬时速度为 "#mi(block: false, "v_1")#"。"],
)
#par[#"如果你使用浮点数进行计算，需要注意潜在的精度问题。"]

#hide(place(top+left, [
]))
