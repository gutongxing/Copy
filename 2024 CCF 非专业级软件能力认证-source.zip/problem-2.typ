#import "header.typ": *

#heading(depth: 2, [#"题目描述"])
#par[#"给定一个长度为 "#mi(block: false, "n")#" 的正整数数组 "#mi(block: false, "A")#"，其中所有数从左至右排成一排。"]
#par[#"你需要将 "#mi(block: false, "A")#" 中的每个数染成红色或蓝色之一，然后按如下方式计算最终得分："]
#par[#"设 "#mi(block: false, "C")#" 为长度为 "#mi(block: false, "n")#" 的整数数组，对于 "#mi(block: false, "A")#" 中的每个数 "#mi(block: false, "A_i")#"（"#mi(block: false, "1 \\leq i \\leq n")#"）："]
#list(
[#"如果 "#mi(block: false, "A_i")#" 左侧没有与其同色的数，则令 "#mi(block: false, "C_i = 0")#"。"],
[#"否则，记其左侧"#strong[#"与其最靠近的同色数"]#"为 "#mi(block: false, "A_j")#"，若 "#mi(block: false, "A_i = A_j")#"，则令 "#mi(block: false, "C_i = A_i")#"，否则令 "#mi(block: false, "C_i = 0")#"。"],
)
#par[#"你的最终得分为 "#mi(block: false, "C")#" 中所有整数的和，即 "#mi(block: false, "\\sum \\limits_{i=1}^n C_i")#"。你需要最大化最终得分，请求出最终得分的最大值。"]
#heading(depth: 2, [#"输入格式"])
#par[#"从文件 "#emph[#"color.in"]#" 中读入数据。"]
#par[#strong[#"本题有多组测试数据。"]]
#par[#"输入的第一行包含一个正整数 "#mi(block: false, "T")#"，表示数据组数。"]
#par[#"接下来包含 "#mi(block: false, "T")#" 组数据，每组数据的格式如下："]
#par[#"第一行包含一个正整数 "#mi(block: false, "n")#"，表示数组长度。"]
#par[#"第二行包含 "#mi(block: false, "n")#" 个正整数 "#mi(block: false, "A_1, A_2, \\dots, A_n")#"，表示数组 "#mi(block: false, "A")#" 中的元素。"]
#heading(depth: 2, [#"输出格式"])
#par[#"输出到文件 "#emph[#"color.out"]#" 中。"]
#par[#"对于每组数据：输出一行包含一个非负整数，表示最终得分的最大可能值。"]
#heading(depth: 2, [#"样例 1 输入"])
#raw(block: true, lang: "txt", "3\n3\n1 2 1\n4\n1 2 3 4\n8\n3 5 2 5 1 2 1 4")
#heading(depth: 2, [#"样例 1 输出"])
#raw(block: true, lang: "txt", "1\n0\n8")
#heading(depth: 2, [#"样例 1 解释"])
#par[#"对于第一组数据，以下为三种可能的染色方案："]
#enum(start: 1,
[#"将 "#mi(block: false, "A_1, A_2")#" 染成红色，将 "#mi(block: false, "A_3")#" 染成蓝色（"#mi(block: false, "\\color{red}{1}\\color{red}{2}\\color{blue}{1}")#"），其得分计算方式如下："],
)
#list(
[#"对于 "#mi(block: false, "A_1")#"，由于其左侧没有红色的数，所以 "#mi(block: false, "C_1 = 0")#"。"],
[#"对于 "#mi(block: false, "A_2")#"，其左侧与其最靠近的红色数为 "#mi(block: false, "A_1")#"。由于 "#mi(block: false, "A_1 \\neq A_2")#"，所以 "#mi(block: false, "C_2 = 0")#"。"],
[#"对于 "#mi(block: false, "A_3")#"，由于其左侧没有蓝色的数，所以 "#mi(block: false, "C_3 = 0")#"。"#"\n"#"该方案最终得分为 "#mi(block: false, "C_1 + C_2 + C_3 = 0")#"。"],
)
#enum(start: 2,
[#"将 "#mi(block: false, "A_1, A_2, A_3")#" 全部染成红色（"#mi(block: false, "\\color{red}{121}")#"），其得分计算方式如下："],
)
#list(
[#"对于 "#mi(block: false, "A_1")#"，由于其左侧没有红色的数，所以 "#mi(block: false, "C_1 = 0")#"。"],
[#"对于 "#mi(block: false, "A_2")#"，其左侧与其最靠近的红色数为 "#mi(block: false, "A_1")#"。由于 "#mi(block: false, "A_1 \\neq A_2")#"，所以 "#mi(block: false, "C_2 = 0")#"。"],
[#"对于 "#mi(block: false, "A_3")#"，其左侧与其最靠近的红色数为 "#mi(block: false, "A_2")#"。由于 "#mi(block: false, "A_2 \\neq A_3")#"，所以 "#mi(block: false, "C_3 = 0")#"。"#"\n"#"该方案最终得分为 "#mi(block: false, "C_1 + C_2 + C_3 = 0")#"。"],
)
#enum(start: 3,
[#"将 "#mi(block: false, "A_1, A_3")#" 染成红色，将 "#mi(block: false, "A_2")#" 染成蓝色（"#mi(block: false, "\\color{red}{1}\\color{blue}{2}\\color{red}{1}")#"），其得分计算方式如下："],
)
#list(
[#"对于 "#mi(block: false, "A_1")#"，由于其左侧没有红色的数，所以 "#mi(block: false, "C_1 = 0")#"。"],
[#"对于 "#mi(block: false, "A_2")#"，由于其左侧没有蓝色的数，所以 "#mi(block: false, "C_2 = 0")#"。"],
[#"对于 "#mi(block: false, "A_3")#"，其左侧与其最靠近的红色数为 "#mi(block: false, "A_1")#"。由于 "#mi(block: false, "A_1 = A_3")#"，所以 "#mi(block: false, "C_3 = A_3 = 1")#"。"#"\n"#"该方案最终得分为 "#mi(block: false, "C_1 + C_2 + C_3 = 1")#"。"],
)
#par[#"可以证明，没有染色方案使得最终得分大于 "#mi(block: false, "1")#"。"]
#par[#"对于第二组数据，可以证明，任何染色方案的最终得分都是 "#mi(block: false, "0")#"。"]
#par[#"对于第三组数据，一种最优的染色方案为将 "#mi(block: false, "A_1, A_2, A_4, A_5, A_7")#" 染为红色，将 "#mi(block: false, "A_3, A_6, A_8")#" 染为蓝色（"#mi(block: false, "\\color{red}{35}\\color{blue}{2}\\color{red}{51}\\color{blue}{2}\\color{red}{1}\\color{blue}{4}")#"），其对应 "#mi(block: false, "C = [0, 0, 0, 5, 0, 2, 1, 0]")#"，最终得分为 "#mi(block: false, "8")#"。"]
#heading(depth: 2, [#"样例 2"])
#par[#"见选手目录下的 "#emph[#"color/color2.in"]#" 与 "#emph[#"color/color2.ans"]#"。"]
#heading(depth: 2, [#"数据范围"])
#par[#"对于所有测试数据，保证："#mi(block: false, "1\\leq T\\leq 10")#"，"#mi(block: false, "2\\leq n\\leq 2\\times 10^5")#"，"#mi(block: false, "1\\leq A_i\\leq 10^6")#"。"]
#figure(table(columns: 3, align: (center + horizon, center + horizon, center + horizon, ),
table.cell()[#"测试点"], table.cell()[#mi(block: false, "n")], table.cell()[#mi(block: false, "A_i")], 
table.cell()[#mi(block: false, "1\\sim 4")], table.cell()[#mi(block: false, "\\leq 15")], table.cell()[#mi(block: false, "\\leq 15")], 
table.cell()[#mi(block: false, "5\\sim 7")], table.cell()[#mi(block: false, "\\leq 10^2")], table.cell()[#mi(block: false, "\\leq 10^2")], 
table.cell()[#mi(block: false, "8\\sim 10")], table.cell()[#mi(block: false, "\\leq 2000")], table.cell()[#mi(block: false, "\\leq 2000")], 
table.cell()[#mi(block: false, "11,12")], table.cell()[#mi(block: false, "\\leq 2\\times 10^4")], table.cell()[#mi(block: false, "\\leq 10^6")], 
table.cell()[#mi(block: false, "13\\sim 15")], table.cell(rowspan: 2, )[#mi(block: false, "\\leq 2\\times 10^5")], table.cell()[#mi(block: false, "\\leq 10")], 
table.cell()[#mi(block: false, "16\\sim 20")], table.cell()[#mi(block: false, "\\leq 10^6")], 
))

#hide(place(top+left, [
]))
